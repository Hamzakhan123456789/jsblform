import React from 'react'
// Bootstrap CSS
import "bootstrap/dist/css/bootstrap.min.css";
// Bootstrap Bundle JS
import "bootstrap/dist/js/bootstrap.bundle.min";
import { Link } from "react-router-dom";

import img1 from "../images/qCWmWh.png"
import img2 from "../images/b4.jpg"

export default function Loginform() {
    return (
        <>

            <div className='logform' style={{ backgroundImage: `url(${img2})` }}>
                <div className='form'>
                    <div className="formdiv">
                        <div className="form-logo">
                            <img src={img1} alt="img" />
                        </div>
                        <form>


                            <div className="form-group mt-4">
                                <label className='label' forhtml="exampleInputEmail1">Email address</label>
                                <input type="email" className="form-control mt-2" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" />
                                {/* <small id="emailHelp" className="form-text text-muted">We'll never share your email with anyone else.</small> */}
                            </div>

                            <div className="form-group mt-4">
                                <label className='label' forhtml="exampleInputPassword1">Password</label>
                                <input type="password" className="form-control mt-2" id="exampleInputPassword1" placeholder="Password" />
                            </div>
                            <div className="form-group form-check mt-4">
                                <input type="checkbox" className="form-check-input" id="exampleCheck1" />
                                <label className="form-check-label label" forhtml="exampleCheck1">Check me out</label>
                            </div>
                            <div className="formbtn mt-4">
                                <Link className="btn btn-primary" to="/Employdata">Submit</Link>
                            </div>


                        </form>
                    </div>
                </div>
            </div>


        </>
    )
}

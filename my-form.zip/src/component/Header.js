import React from 'react'
import img1 from "../images/qCWmWh.png"
export default function Header() {
    return (
        <>
            <div className="header">
                <div className="container">
                    <div className="headerf">
                        <div className="logo">
                            <img src={img1} alt="" />
                        </div>

                        <div className="iconboc">

                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

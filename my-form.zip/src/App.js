import './App.css';
import Loginform from './component/Loginform';
import Employdata from './component/Employdata';
import { BrowserRouter, Route, Routes } from "react-router-dom";




function App() {
  return (

    <>
 <BrowserRouter>
    <Routes>
      <Route path="/" element={<Loginform />} />
      <Route path="/Employdata" element={<Employdata />} />
      
    </Routes>
  </BrowserRouter>
    </>
    // <div className="App">

    //  <Loginform />
    
    //  <Employdata />
    // </div>
  );
}

export default App;
